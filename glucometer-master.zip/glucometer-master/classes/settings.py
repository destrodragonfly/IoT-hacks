def init():
    global brightness
    global calibration_mode

    brightness = 500
    calibration_mode = False

